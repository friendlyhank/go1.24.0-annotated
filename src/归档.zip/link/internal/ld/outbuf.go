package ld

import (
	"cmd/internal/sys"
	"errors"
	"os"
)

/*
 * 输出文件
 */

const outbufMode = 0775

type OutBuf struct {
	arch *sys.Arch

	name string // 文件名
	f    *os.File
}

func (out *OutBuf) Open(name string) error {
	if out.f != nil {
		return errors.New("cannot open more than one file")
	}
	f, err := os.OpenFile(name, os.O_RDWR|os.O_CREATE|os.O_TRUNC, outbufMode)
	if err != nil {
		return err
	}
	out.name = name
	out.f = f
	return nil
}

func NewOutBuf(arch *sys.Arch) *OutBuf {
	return &OutBuf{
		arch: arch,
	}
}
