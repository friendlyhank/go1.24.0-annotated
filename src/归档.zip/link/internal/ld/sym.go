package ld

import "cmd/internal/sys"

func linknew(arch *sys.Arch) *Link {
	ctxt := &Link{
		Out: NewOutBuf(arch),
	}
	return ctxt
}
