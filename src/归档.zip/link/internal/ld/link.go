package ld

type Link struct {
	Out *OutBuf // 链接器文件输出文件buf
}
