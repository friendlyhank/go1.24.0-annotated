package ld

type Arch struct{}

// libinit - link初始化
func libinit(ctxt *Link) {
	// 临时先不生成文件
	//if err := ctxt.Out.Open(*flagOutfile); err != nil {
	//	Exitf("cannot create %s: %v", *flagOutfile, err)
	//}
}
