package ld

import (
	"fmt"
	"os"
)

// Exit exits with code after executing all atExitFuncs.
func Exit(code int) {
	os.Exit(code)
}

// Exitf logs an error message then calls Exit(2).
func Exitf(format string, a ...interface{}) {
	fmt.Fprintf(os.Stderr, os.Args[0]+": "+format+"\n", a...)
	Exit(2)
}
